class Actor(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  fc1 : __torch__.torch.nn.modules.container.Sequential
  fc2 : __torch__.torch.nn.modules.container.___torch_mangle_2.Sequential
  fc3 : __torch__.torch.nn.modules.container.___torch_mangle_4.Sequential
  def forward(self: __torch__.Model.Actor,
    input: Tensor) -> Tensor:
    _0 = self.fc3
    _1 = (self.fc2).forward((self.fc1).forward(input, ), )
    return (_0).forward(_1, )
