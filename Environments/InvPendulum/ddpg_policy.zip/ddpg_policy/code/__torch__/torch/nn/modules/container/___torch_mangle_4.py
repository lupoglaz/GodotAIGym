class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.modules.linear.___torch_mangle_3.Linear
  __annotations__["1"] = __torch__.torch.nn.modules.activation.Tanh
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_4.Sequential,
    argument_1: Tensor) -> Tensor:
    _0 = getattr(self, "1")
    _1 = (getattr(self, "0")).forward(argument_1, )
    return (_0).forward(_1, )
